package br.com.senac.tuktuk.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "endereco_cadastro")
public class EnderecoCadastro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_endereco;

    @Column
    private String cidade;

    @Column
    private String uf;

    @Column
    private String cep;

    @Column
    private String end_completo;

    @Column
    private String nr_casa;

    @Column
    private String bairro;

    @Column
    private String situacao;

     @OneToMany(mappedBy="endereco")
    private List<Cliente> cliente;

    @OneToMany(mappedBy="endereco")
    private List<Colaborador> colaborador;

    //getters and setters
    public int getId_endereco() {
        return id_endereco;
    }

    public void setId_endereco(int id_endereco) {
        this.id_endereco = id_endereco;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String e) {
        this.cep = e;
    }

    public String getEnd_completo() {
        return end_completo;
    }

    public void setEnd_completo(String end_completo) {
        this.end_completo = end_completo;
    }

    public String getNr_casa() {
        return nr_casa;
    }

    public void setNr_casa(String nr_casa) {
        this.nr_casa = nr_casa;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public List<Cliente> getCliente() {
        return cliente;
    }

    public void setCliente(List<Cliente> cliente) {
        this.cliente = cliente;
    }

    public List<Colaborador> getColaborador() {
        return colaborador;
    }

    public void setColaborador(List<Colaborador> colaborador) {
        this.colaborador = colaborador;
    }

    public static EnderecoCadastro setEnderecoCadastro(EnderecoCadastro e) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setEnderecoCadastro'");
    }
    
}