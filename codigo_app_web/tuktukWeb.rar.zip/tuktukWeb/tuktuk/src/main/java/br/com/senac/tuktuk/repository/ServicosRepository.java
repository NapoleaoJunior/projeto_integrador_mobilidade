package br.com.senac.tuktuk.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.senac.tuktuk.controller.ServicosController;
import br.com.senac.tuktuk.entity.Servico_inicializados;


public interface ServicosRepository extends JpaRepository<ServicosRepository,Integer> {
    
    ArrayList<ServicosRepository> findByNomeLike(String nome);    
    
    ArrayList<ServicosRepository> findByPrecoGreaterThanEqual(float preco);

    ArrayList<ServicosRepository> findByPrecoLessThanEqual(float preco);

    Object getEndereco();

    List<ServicosController> findByTipoLike(String string);

    ServicosController saveServicos(Servico_inicializados servicos);

    ServicosController save(ServicosController servicos);

    static void ServicosRepository(Optional<ServicosController> servicoExistente) {
        throw new UnsupportedOperationException("Unimplemented method 'ServicosRepository'");
    }

    void saveAll(ServicosController servicos);
}
