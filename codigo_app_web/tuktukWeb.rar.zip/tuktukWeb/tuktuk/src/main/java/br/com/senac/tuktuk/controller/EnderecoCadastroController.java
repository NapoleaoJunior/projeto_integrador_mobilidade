package br.com.senac.tuktuk.controller;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.senac.tuktuk.entity.EnderecoCadastro;
import br.com.senac.tuktuk.repository.EnderecoRepository;
import jakarta.persistence.Entity;

@RestController
@RequestMapping("/enderecos")
public class EnderecoCadastroController<enderecoServico> {
    private final EnderecoRepository enderecoRepository;
    public EnderecoCadastroController(EnderecoRepository enderecoRepository) {
        this.enderecoRepository = enderecoRepository;
    }
    // Método GET para obter todos os endereços
    @GetMapping
    public ResponseEntity<?> getEnderecos() {
        try {
            return new ResponseEntity<>(enderecoRepository.findById(id), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    // Método GET para obter um endereço por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getEnderecoById(@PathVariable Long id) {
        try {
            Optional<enderecoServico> endereco = (Optional<enderecoServico>) enderecoRepository.find(id);
            if (endereco.isPresent()) {
                return new ResponseEntity<>(endereco.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Endereço não encontrado", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    // Método POST para criar um novo endereço
    @PostMapping
    public ResponseEntity<?> createEndereco(@RequestBody enderecoServico endereco) {
        try {
            final enderecoServico novoEndereco = enderecoRepository.save(Entity);
            return new ResponseEntity<>(novoEndereco, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    // Método PUT para atualizar um endereço existente
   @PutMapping("endereco/{id}")
    public void atualizaEndereco(@PathVariable int id, @RequestBody EnderecoCadastro entity) {
        EnderecoCadastro e = null;
    }
}

