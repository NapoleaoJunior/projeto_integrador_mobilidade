package br.com.senac.tuktuk.entity;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "colaborador")
public class Colaborador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_colaborador;
    @Column
    private String nome;
    @Column
    private String cnpj;
    @Column
    private String email;
    @Column
    private Date data_nascimento;
    @Column
    private String cnh;
    @Column
    private Date dtvenci_cnh;
    @Column
    private String genero;
    @Column
    private String nome_usuario;
    @Column
    private String senha_login;
    @Column
    private String situacao;
    @Column
    private String celular;
    @Column
    private Date data_fimcontrato;
    @Column
    private String cpf;
    @Column
    private Date data_iniciocontrato;

    @OneToMany(mappedBy = "colaborador")
    private List<Servicos> servicos;

    // getters and setters
    public int getId_colaborador() {
        return id_colaborador;
    }

    public void setId_colaborador(int id_colaborador) {
        this.id_colaborador = id_colaborador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(Date data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public Date getDtvenci_cnh() {
        return dtvenci_cnh;
    }

    public void setDtvenci_cnh(Date dtvenci_cnh) {
        this.dtvenci_cnh = dtvenci_cnh;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getNome_usuario() {
        return nome_usuario;
    }

    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    public String getSenha_login() {
        return senha_login;
    }

    public void setSenha_login(String senha_login) {
        this.senha_login = senha_login;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public Date getData_fimcontrato() {
        return data_fimcontrato;
    }

    public void setData_fimcontrato(Date data_fimcontrato) {
        this.data_fimcontrato = data_fimcontrato;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_iniciocontrato() {
        return data_iniciocontrato;
    }

    public void setData_iniciocontrato(Date data_iniciocontrato) {
        this.data_iniciocontrato = data_iniciocontrato;
    }

    public List<Servicos> getServicos() {
        return servicos;
    }

    public void setServicos(List<Servicos> servicos) {
        this.servicos = servicos;
    }

    public void setId(Long id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Long getId() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
