package br.com.senac.tuktuk.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.senac.tuktuk.entity.Colaborador;
import br.com.senac.tuktuk.repository.ColaboradorRepository;
import br.com.senac.tuktuk.repository.EnderecoRepository;
import br.com.senac.tuktuk.repository.ServicosRepository;
import br.com.senac.tuktuk.entity.EnderecoServico;

@RestController
public class ServicosController{

    private ServicosRepository servicosRepository;
    private EnderecoRepository enderecoRepository;
    private ColaboradorRepository colaboradorRepository;
    private Object servicoRepository;

    public ServicosController(ServicosRepository servicosRepository, EnderecoRepository enderecoRepository, ColaboradorRepository colaboradorRepository) {
    this.servicosRepository = servicosRepository;
    this.enderecoRepository = enderecoRepository;
    this.colaboradorRepository = colaboradorRepository;
}
    
    // Endpoint para listar todos os serviços
@GetMapping("/Servicos")
public ResponseEntity<List<ServicosController>> getDadosSEntity() {
    List<ServicosController> servicos = (List<ServicosController>) servicoRepository;
    return ResponseEntity.ok(servicos);
}

// Endpoint para buscar serviço por ID
@GetMapping("/servicos/{id}")
public ResponseEntity<?> obterPorId(@PathVariable int id) {
    Optional<Colaborador> servico = ((ColaboradorRepository) servicoRepository).findById(id);

    return servico.map(valor -> new ResponseEntity<>(valor, HttpStatus.OK))
                  .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
}

        @GetMapping("servicos/valor_servico/{valor_servico}")
            public ResponseEntity<?> getByValorServico(@PathVariable float valor_servico) {
                return new ResponseEntity<>(servicosRepository.findByPrecoGreaterThanEqual(valor_servico), HttpStatus.OK);
            }


        // Endpoint para listar todos os serviços
        @GetMapping("/servicos")
            public ResponseEntity<List<ServicosRepository>> listarServicos() {
                List<ServicosRepository> servicos = servicosRepository.findAll();
                return ResponseEntity.ok(servicos);
            }

            
    
            // Endpoint para salvar novo serviço
@PostMapping("/Servicos")
public ResponseEntity<?> salvaServicos(@RequestBody ServicosController servicos) {
    // Verifica se o endereço e o colaborador existem
        if (enderecoRepository.isEmpty() || colaboradorRepository.isEmpty()) {
            String mensagemErro = enderecoRepository.isEmpty() ? "Endereço não encontrado" : "Colaborador não encontrado";
            return new ResponseEntity<>(mensagemErro, HttpStatus.BAD_REQUEST);
        }
        try {
            // Associa o endereço e o colaborador ao serviço
            servicos.setEndereco(enderecoRepository.get());
                    Object servicosSalvo = null;
                                            // Salva o serviço no repositório e obtém o serviço salvo
                                            // Retorna o serviço salvo com status de solicitação foi bem-sucedida
                                            return new ResponseEntity<>(servicosSalvo, HttpStatus.CREATED);
                    } catch (DataIntegrityViolationException e) {
                        // Tratamento de exceção específico (violação de integridade de dados)
                        return new ResponseEntity<>("Erro de integridade de dados ao salvar o serviço: " + e.getMessage(), HttpStatus.BAD_REQUEST);
                    } catch (Exception e) {
                        // Mensagem de erro genérica para outros tipos de erro
                        return new ResponseEntity<>("Erro ao salvar o serviço: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                }
                
                
                        private void setEndereco(EnderecoServico enderecoServico) {

                throw new UnsupportedOperationException("Unimplemented method 'setEndereco'");
            }
            
                        private Long getEndereco() {
        throw new UnsupportedOperationException("Unimplemented method 'getEndereco'");
    }
    
         // Endpoint para excluir serviço
        @DeleteMapping("/servicos/{id}")
            public ResponseEntity<String> deleteProduto(@PathVariable int id) {
                Optional<ServicosController> servicoExcluir = Optional.empty();
                
        if (servicoExcluir.isPresent()) {
            try {
                servicosRepository.delete((ServicosRepository) servicoExcluir.get());
                return new ResponseEntity<>("Serviço excluído com sucesso", HttpStatus.NO_CONTENT);
            } catch (Exception e) {
            return new ResponseEntity<>("Erro ao excluir o serviço", HttpStatus.BAD_REQUEST);
            }
                } else {
            return new ResponseEntity<>("Serviço não encontrado", HttpStatus.NOT_FOUND);
                }
        }

}
