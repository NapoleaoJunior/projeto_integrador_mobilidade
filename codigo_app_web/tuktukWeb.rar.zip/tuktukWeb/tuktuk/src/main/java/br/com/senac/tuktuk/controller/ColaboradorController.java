package br.com.senac.tuktuk.controller;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.senac.tuktuk.entity.Colaborador;
import br.com.senac.tuktuk.repository.ColaboradorRepository;

@RestController
@RequestMapping("/colaboradores")
public class ColaboradorController {

    private final ColaboradorRepository colaboradorRepository;

    // Injeção do repositório correto
    public ColaboradorController(ColaboradorRepository colaboradorRepository) {
        this.colaboradorRepository = colaboradorRepository;
    }

    // Método GET para listar todos os colaboradores
    @GetMapping
    public ResponseEntity<?> getAllColaboradores() {
        try {
            return new ResponseEntity<>(colaboradorRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Método GET para obter um colaborador por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getColaboradorById(@PathVariable Long id) {
        try {
            Optional<Colaborador> colaborador = colaboradorRepository.findById(id);
            if (colaborador.isPresent()) {
                return new ResponseEntity<>(colaborador.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Colaborador não encontrado", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Método POST para criar um novo colaborador
    @PostMapping
    public ResponseEntity<?> createColaborador(@RequestBody Colaborador colaborador) {
        try {
            Colaborador novoColaborador = colaboradorRepository.save(colaborador);
            return new ResponseEntity<>(novoColaborador, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Método PUT para atualizar um colaborador existente
    @PutMapping("/{id}")
    public ResponseEntity<?> updateColaborador(@PathVariable Long id, @RequestBody Colaborador colaborador) {
        try {
            Optional<Colaborador> colaboradorExistente = colaboradorRepository.findById(id);
            if (colaboradorExistente.isPresent()) {
                colaborador.setId(id);  // Garantir que o ID do colaborador é mantido
                Colaborador colaboradorAtualizado = colaboradorRepository.save(colaborador);
                return new ResponseEntity<>(colaboradorAtualizado, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Colaborador não encontrado", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Método DELETE para excluir um colaborador
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteColaborador(@PathVariable Long id) {
        try {
            if (colaboradorRepository.existsById(id)) {
                colaboradorRepository.deleteById(id);
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>("Colaborador não encontrado", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
