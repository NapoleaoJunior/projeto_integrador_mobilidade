package br.com.senac.tuktuk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuktukApplicationTests {

	@Test
	void contextLoads() {
	}

}
